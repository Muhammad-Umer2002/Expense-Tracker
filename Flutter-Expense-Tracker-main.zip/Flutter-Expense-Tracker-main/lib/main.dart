import 'package:flutter/material.dart';
import 'package:expense_tracker/widgets/expenses.dart';
// import 'package:flutter/services.dart';

var klorscheme = ColorScheme.fromSeed(
  seedColor: const Color.fromARGB(74, 132, 169, 255),
);
var darkscheme = ColorScheme.fromSeed(
  seedColor: const Color.fromARGB(255, 5, 9, 125),
);
void main() {
  // WidgetsFlutterBinding.ensureInitialized();
  // SystemChrome.setPreferredOrientations(
  //   [DeviceOrientation.portraitUp],
  // ).then((fn) {
    runApp(
      MaterialApp(
        darkTheme: ThemeData.dark().copyWith(colorScheme: darkscheme),
        theme: ThemeData().copyWith(
          colorScheme: klorscheme,
          appBarTheme: const AppBarTheme().copyWith(
            backgroundColor: klorscheme.onPrimaryContainer,
            foregroundColor: klorscheme.primaryContainer,
          ),
          cardTheme: const CardTheme().copyWith(
              color: klorscheme.secondaryContainer,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8)),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: klorscheme.primaryContainer,
            ),
          ),
          textTheme: ThemeData().textTheme.copyWith(
                titleLarge: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: klorscheme.onSecondaryContainer,
                  fontSize: 24,
                ),
              ),
        ),
        home: const Expenses(),
      ),
    );
  // });
}
